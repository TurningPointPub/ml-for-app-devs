import CreateML
import SpriteKit
import PlaygroundSupport

//데이터셋 작성
var label = 0
var labels: [String] = []
var texts: [String] = []
let paths: [String] = [//★환경에 맞춰 각자 경로를 변경해주세요
    "/Users/유저명/Documents/store/book/MLPhone/sample/ch4/TextClassification.playground/Resources/text/it",
    "/Users/유저명/Documents/store/book/MLPhone/sample/ch4/TextClassification.playground/Resources/text/sports"]
for path in paths {
    let files = try FileManager.default.contentsOfDirectory(atPath: path)
    var count = 0;
    for file in files {
        //텍스트 불러오기
        var text = try! String(contentsOfFile: path+"/"+file,
            encoding: String.Encoding.utf8)
        text = text.components(separatedBy: "\n")[3] //타이틀만 추출
        
        //텍스트 와 라벨 추가
        texts.append(text)
        labels.append(String(label))
        
        //최대 400
        count = count + 1
        if (count >= 400) {break}
    }
    label += 1
}
let dic: [String: MLDataValueConvertible] = [
    "text": texts,
    "label": labels
]
let data = try MLDataTable(dictionary: dic)
print(data)

//훈련 데이터와 평가데이터의 분할
let (train_data, test_data) = data.randomSplit(by: 0.8, seed: 5)


//학습
let classifier = try MLTextClassifier(
    trainingData: train_data, textColumn: "text", labelColumn: "label")


//훈련데이터 정답률
let trainAccuracy = (1.0 - classifier.trainingMetrics.classificationError) * 100.0
print("Training Accuracy: ", trainAccuracy)

//검층데이터 정답률
let validAccuracy = (1.0 - classifier.validationMetrics.classificationError) * 100.0
print("Validation Accuracy: ", validAccuracy)


//평가
let evaluation = classifier.evaluation(on: test_data)

//평가데이터 정답률
let evalAccuracy = (1.0 - evaluation.classificationError) * 100.0
print("Evaluation Accuracy: ", evalAccuracy)


//모델 메타데이터 작성
let metadata = MLModelMetadata(
    author: "npaka",
    shortDescription: "뉴스 카테고리 예측모델",
    version: "1.0")

//모델 보존장소 작성
let directory = playgroundSharedDataDirectory.appendingPathComponent(
    "TextClassification.mlmodel")

//모델 보존
try classifier.write(to: directory, metadata: metadata)
