import CreateML
import SpriteKit
import PlaygroundSupport

//데이터셋 읽어오기
let url = Bundle.main.url(forResource: "winequality-red", withExtension: "csv")!
let data = try MLDataTable(contentsOf: url)
print(data)

//평가데이터 와 훈련데이터 분할
let (train_data, test_data) = data.randomSplit(by: 0.8, seed: 5)


//학습
let regressor = try MLRegressor(trainingData: train_data,
    targetColumn: "quality")


//훈련데이터 RMSE
print("Training RMSE: ", regressor.trainingMetrics.rootMeanSquaredError)

//검증데이트 RMSE
print("Validation RMSE: ", regressor.validationMetrics.rootMeanSquaredError)


//평가
let evaluation = regressor.evaluation(on: test_data)

//평가데이터 RMSE
print("Evaluation RMSE: ", evaluation.rootMeanSquaredError)


//모델 메타데이터 작성
let metadata = MLModelMetadata(
    author: "npaka",
    shortDescription: "레드와인 품질예측 모델",
    version: "1.0")

//모델보존 장소 작성
let directory = playgroundSharedDataDirectory.appendingPathComponent(
    "Regression.mlmodel")

//모델보존
try regressor.write(to: directory, metadata: metadata)
