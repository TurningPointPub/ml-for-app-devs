import CreateML
import SpriteKit
import PlaygroundSupport

//데이터셋 읽어오기
let url = Bundle.main.url(forResource: "agaricus-lepiota", withExtension: "csv")!
let data = try MLDataTable(contentsOf: url)
print(data)

//훈련데이터 와 평가데이텨 분할
let (train_data, test_data) = data.randomSplit(by: 0.8, seed: 5)


//학습
let classifier = try MLClassifier(trainingData: train_data,
    targetColumn: "label")


//훈련데이터 정답률
let trainAccuracy = (1.0 - classifier.trainingMetrics.classificationError) * 100.0
print("Training Accuracy: ", trainAccuracy)

//검증데이터 정답률
let validAccuracy = (1.0 - classifier.validationMetrics.classificationError) * 100.0
print("Validation Accuracy: ", validAccuracy)


//평가
let evaluation = classifier.evaluation(on: test_data)

//평가데이터 정답률
let evalAccuracy = (1.0 - evaluation.classificationError) * 100.0
print("Evaluation Accuracy: ", evalAccuracy)


//모델 메타데이터 작성
let metadata = MLModelMetadata(
    author: "npaka",
    shortDescription: "독버섯 예측모델",
    version: "1.0")

//모델 보존장소 작성
let directory = playgroundSharedDataDirectory.appendingPathComponent(
    "Classification.mlmodel")

//모델 보존
try classifier.write(to: directory, metadata: metadata)
