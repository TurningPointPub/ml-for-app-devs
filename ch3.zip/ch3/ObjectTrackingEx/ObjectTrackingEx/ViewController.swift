import UIKit
import AVFoundation
import Vision

//물체이동 트랙킹
class ViewController: UIViewController,
    AVCaptureVideoDataOutputSampleBufferDelegate,
    UIGestureRecognizerDelegate {
    //UI
    @IBOutlet weak var drawView: DrawView!
    var previewLayer: AVCaptureVideoPreviewLayer!
    
    //(3)시퀀스 리퀘스트 핸들러 생성
    var handler = VNSequenceRequestHandler()

    
//====================
//라이프사이클
//====================
    //로딩시 호출
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //탭 제스처 추가
        let tapGesture = UITapGestureRecognizer(
            target: self, action: #selector(ViewController.onTapped))
        tapGesture.delegate = self
        self.view.addGestureRecognizer(tapGesture)
        
        //오래 누르기 제스처 개시
        let longPressGesture = UILongPressGestureRecognizer(
            target: self, action: #selector(ViewController.onLongPressed))
        longPressGesture.delegate = self
        self.view.addGestureRecognizer(longPressGesture)
    }
    
    //뷰 표시시 호출
    override func viewDidAppear(_ animated: Bool) {
        //카메라캡처 시작
        startCapture()
    }
    
    
 //====================
 //이벤트
 //====================
    //(2)탭시 호출
    @objc func onTapped(_ sender: UITapGestureRecognizer) {
        //이미지 좌표계 타겟 영역
        let position = sender.location(in: self.drawView)
        var rect = CGRect(
            x: position.x-50, y: position.y+50,
            width: 100, height: 100)

        //이미지 좌표계를 검출결과 좌표계로 변환
        rect = self.drawView.inversConvertRect(rect)
        if (rect == CGRect.zero) {return}

        //VNDetectedObjectObservation 생성
        self.drawView.target = VNDetectedObjectObservation(boundingBox: rect)
    }
 
    //(3)오래 누르기시 호출
    @objc func onLongPressed(_ sender: Any) {
        DispatchQueue.main.async {
            //타겟삭제
            self.drawView.target = nil
            
            //UI 업데이트
            self.drawView.setNeedsDisplay()
        }
    }
    
    
//====================
//경고
//====================
    //경고표시
    func showAlert(_ text: String!) {
        let alert = UIAlertController(title: text, message: nil,
            preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",
            style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
//====================
//카메라캡처
//====================
    //카메라캡처 시작
    func startCapture() {
        //세션 초기화
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = AVCaptureSession.Preset.photo

        //입력지정
        let captureDevice: AVCaptureDevice! = self.device(false)
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else {return}
        guard captureSession.canAddInput(input) else {return}
        captureSession.addInput(input)
        
        //출력지정
        let output: AVCaptureVideoDataOutput = AVCaptureVideoDataOutput()
        output.setSampleBufferDelegate(self, queue: DispatchQueue(label: "VideoQueue"))
        guard captureSession.canAddOutput(output) else {return}
        captureSession.addOutput(output)
        let videoConnection = output.connection(with: AVMediaType.video)
        videoConnection!.videoOrientation = .portrait

        //프리뷰지정
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        previewLayer.frame = self.drawView.frame
        self.view.layer.insertSublayer(previewLayer, at: 0)
        
        //카메라캡처 시작
        captureSession.startRunning()
    }
    
    //디바이스 획득
    func device(_ frontCamera: Bool) -> AVCaptureDevice! {
        let position: AVCaptureDevice.Position = frontCamera ? .front : .back
        let deviceDiscoverySession = AVCaptureDevice.DiscoverySession(
            deviceTypes: [AVCaptureDevice.DeviceType.builtInWideAngleCamera],
            mediaType: AVMediaType.video,
            position: AVCaptureDevice.Position.unspecified)
        let devices = deviceDiscoverySession.devices
        for device in devices {
            if device.position == position {
                return device
            }
        }
        return nil
    }

    //카메라캡처 획득시 호출
    func captureOutput(_ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection) {
        predict(sampleBuffer)
    }
    
    
//====================
//물체이동 트래킹
//====================
    //(1)예측
    func predict(_ sampleBuffer: CMSampleBuffer) {
        //이미지크기 지정
        DispatchQueue.main.async {
            let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)
            self.drawView.setImageSize(CGSize(
                width: CGFloat(CVPixelBufferGetWidth(imageBuffer!)),
                height: CGFloat(CVPixelBufferGetHeight(imageBuffer!))))
        }

        //리퀘스트 생성
        if (self.drawView.target == nil) {return}
        let request = VNTrackObjectRequest(
            detectedObjectObservation: self.drawView.target) {
            request, error in
            //에러처리
            if error != nil {
                self.showAlert(error!.localizedDescription)
                return
            }
            
            DispatchQueue.main.async {
                //검출정보 획득
                self.drawView.target = (request.results!.first! as!
                    VNDetectedObjectObservation)
                
                //UI 업데이트
                self.drawView.setNeedsDisplay()
            }
        }
        
        //위치정확성 우선
        request.trackingLevel = .accurate

        //CMSampleBuffer를 CVPixelBuffer로 변환
        let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)!
 
        //시퀀스 리퀘스트 핸들러 실행
        guard (try? handler.perform([request], on: pixelBuffer)) != nil else {return}
    }
}
