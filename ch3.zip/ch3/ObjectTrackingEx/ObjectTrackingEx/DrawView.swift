import UIKit
import Vision

//그리기 뷰
class DrawView: UIView {
    //정수
    let COLOR_BLUE: UIColor = UIColor(red: 0.0, green: 0.0, blue: 255.0, alpha: 0.5)
    let COLOR_WHITE: UIColor = UIColor.white

    //속성
    var imageRect: CGRect = CGRect.zero
    
    //타겟유지
    var target: VNDetectedObjectObservation! = nil

    //이미지크기 지정
    func setImageSize(_ imageSize: CGSize) {
        //이미지 표시영역 계산(AspectFill)
        let scale: CGFloat =
            (self.frame.width/imageSize.width > self.frame.height/imageSize.height) ?
            self.frame.width/imageSize.width :
            self.frame.height/imageSize.height
        let dw: CGFloat = imageSize.width*scale
        let dh: CGFloat = imageSize.height*scale
        self.imageRect = CGRect(
            x: (self.frame.width-dw)/2,
            y: (self.frame.height-dh)/2,
            width: dw, height: dh)
    }

    //(4)검출결과 그리기
    override func draw(_ rect: CGRect) {
        if self.target == nil {return}
        
        //그래칙스 컨텍스트 생성
        let context = UIGraphicsGetCurrentContext()!

        //영역 그리기
        let rect = convertRect(self.target.boundingBox)
        context.setStrokeColor(COLOR_BLUE.cgColor)
        context.setLineWidth(6)
        context.stroke(rect)
    }

    //검출영역 좌표계를 화면 좌표계로 변환
    func convertRect(_ rect:CGRect) -> CGRect {
        return CGRect(
            x: self.imageRect.minX + rect.minX * self.imageRect.width,
            y: self.imageRect.minY + (1 - rect.maxY) * self.imageRect.height,
            width: rect.width * self.imageRect.width,
            height: rect.height * self.imageRect.height)
    }
    
    //화면 좌표계를 검출영역 좌표계로 변환
    func inversConvertRect(_ rect:CGRect) -> CGRect {
        if (self.imageRect == CGRect.zero) {return CGRect.zero}
        return CGRect(
            x: (rect.minX - self.imageRect.minX) / self.imageRect.width,
            y: 1 - (rect.minY - self.imageRect.minY) / self.imageRect.height,
            width: rect.width / self.imageRect.width,
            height: rect.height / self.imageRect.height)
    }
}
