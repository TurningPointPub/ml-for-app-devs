import UIKit
import CoreML
import Vision

//수평선 검출
class ViewController: UIViewController,
    UINavigationControllerDelegate,
    UIImagePickerControllerDelegate,
    UIGestureRecognizerDelegate {
    //UI
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var lblText: UILabel!


//====================
//라이프사이클
//====================
    //뷰 표시시 호출
    override func viewDidAppear(_ animated: Bool) {
        //액션시트 표시
        if self.imageView.image == nil {
            showActionSheet()
        }
    }
    
    
//====================
//이벤트
//====================
    //화면터치시 호출
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        showActionSheet()
    }


//====================
//액션시트
//====================
    //액션시트 표시
    func showActionSheet() {
        let actionSheet = UIAlertController(title: nil, message: nil,
            preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "카메라", style: .default) {
            action in
            self.openPicker(sourceType: .camera)
        })
        actionSheet.addAction(UIAlertAction(title: "사진 라이브러리", style: .default) {
            action in
            self.openPicker(sourceType: .photoLibrary)
        })
        actionSheet.addAction(UIAlertAction(title: "취소", style: .cancel))
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
//====================
//경고
//====================
    //경고표시
    func showAlert(_ text: String!) {
        let alert = UIAlertController(title: text, message: nil,
            preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",
            style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
   
   
//====================
//이미지피커
//====================
    //이미지피커 시작
    func openPicker(sourceType: UIImagePickerController.SourceType) {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }

    //이미지피커 이미지 획득시 호출
    func imagePickerController(_ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //이미지 획득
        var image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        
        //이미지 방향보정
        let size = image.size
        UIGraphicsBeginImageContext(size)
        image.draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        image = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()

        //이미지 지정
        self.imageView.image = image
        
        //닫기
        picker.presentingViewController!.dismiss(animated:true, completion:nil)

        //예측
        predict(image)
    }
    
    //이미지피커 취소시 호출
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        //닫기
        picker.presentingViewController!.dismiss(animated:true, completion:nil)
    }
    
    
//====================
//수평선 검출
//====================
    //(1)예측
    func predict(_ image: UIImage) {
        DispatchQueue.global(qos: .default).async {
            //리퀘스트 생성
            let request = VNDetectHorizonRequest {
                request, error in
                //에러처리
                if error != nil {
                    self.showAlert(error!.localizedDescription)
                    return
                }
                
               DispatchQueue.main.async {
                    //검출결과 획득
                    let horizons = request.results as! [VNHorizonObservation]
                
                    //UI 업데이트
                    if horizons.first == nil {
                        self.imageView.transform = CGAffineTransform(rotationAngle: 0)
                        self.lblText.text = "検出失敗"
                    } else {
                        let angle = horizons.first!.angle
                        self.imageView.transform = CGAffineTransform(rotationAngle: -angle)
                        self.lblText.text = String(format:"\nAngle : %.2f度\n",
                            -angle*180/CGFloat(Double.pi))
                    }
                }
            }

            //UIImage를 CIImage로 변환
            guard let ciImage = CIImage(image: image) else {return}
        
            //이미지 방향 획득
            let orientation = CGImagePropertyOrientation(
                rawValue: UInt32(image.imageOrientation.rawValue))!
        
            //핸들러 생성과 실행
            let handler = VNImageRequestHandler(
                ciImage: ciImage, orientation: orientation)
            guard (try? handler.perform([request])) != nil else {return}
        }
    }
}
