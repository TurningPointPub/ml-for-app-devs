import UIKit
import AVFoundation
import Vision

//얼굴검출
class ViewController: UIViewController,
    AVCaptureVideoDataOutputSampleBufferDelegate {
    //UI
    @IBOutlet weak var lblText: UILabel!
    @IBOutlet weak var drawView: DrawView!
    var previewLayer: AVCaptureVideoPreviewLayer!


//====================
//라이프사이클
//====================
    //뷰 표시시 호출
    override func viewDidAppear(_ animated: Bool) {
        //카메라캡처 시작
        startCapture()
    }
    
    
//====================
//경고
//====================
    //경고표시
    func showAlert(_ text: String!) {
        let alert = UIAlertController(title: text, message: nil,
            preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",
            style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
//====================
//카메라캡처
//====================
    //카메라캡처 시작
    func startCapture() {
        //세션 초기화
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = AVCaptureSession.Preset.photo

        //입력지정
        let captureDevice: AVCaptureDevice! = self.device(false)
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else {return}
        guard captureSession.canAddInput(input) else {return}
        captureSession.addInput(input)
        
        //출력지정
        let output: AVCaptureVideoDataOutput = AVCaptureVideoDataOutput()
        output.setSampleBufferDelegate(self, queue: DispatchQueue(label: "VideoQueue"))
        guard captureSession.canAddOutput(output) else {return}
        captureSession.addOutput(output)
        let videoConnection = output.connection(with: AVMediaType.video)
        videoConnection!.videoOrientation = .portrait

        //프리뷰 지정
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        previewLayer.frame = self.drawView.frame
        self.view.layer.insertSublayer(previewLayer, at: 0)
        
        //카메라캡처 시작
        captureSession.startRunning()
    }
    
    //디바이스 획득
    func device(_ frontCamera: Bool) -> AVCaptureDevice! {
        let position: AVCaptureDevice.Position = frontCamera ? .front : .back
        let deviceDiscoverySession = AVCaptureDevice.DiscoverySession(
            deviceTypes: [AVCaptureDevice.DeviceType.builtInWideAngleCamera],
            mediaType: AVMediaType.video,
            position: AVCaptureDevice.Position.unspecified)
        let devices = deviceDiscoverySession.devices
        for device in devices {
            if device.position == position {
                return device
            }
        }
        return nil
    }

    //카메라캡처 획득시 호출
    func captureOutput(_ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection) {
        predict(sampleBuffer)
    }
    
    
//====================
//얼굴검출
//====================
    //(1)예측
    func predict(_ sampleBuffer: CMSampleBuffer) {
        //리퀘스트 생성
        let request = VNDetectFaceLandmarksRequest {
            request, error in
            //에러처리
            if error != nil {
                self.showAlert(error!.localizedDescription)
                return
            }
            
            DispatchQueue.main.async {
                //검출결과 획득
                let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)
                self.drawView.setImageSize(CGSize(
                    width: CGFloat(CVPixelBufferGetWidth(imageBuffer!)),
                    height: CGFloat(CVPixelBufferGetHeight(imageBuffer!))))
                self.drawView.faces = (request.results as! [VNFaceObservation])
                
                //UI 업데이트
                self.drawView.setNeedsDisplay()
            }
        }
        
        //CMSampleBuffer를 CVPixelBuffer로 변환
        let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)!

        //핸들러 생성과 실행
        let handler = VNImageRequestHandler(cvPixelBuffer:pixelBuffer, options:[:])
        guard (try? handler.perform([request])) != nil else {return}
    }
}
