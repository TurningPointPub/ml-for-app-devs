import UIKit
import CoreML
import Vision
import NaturalLanguage //(1)

//자연어 처리
class ViewController: UIViewController, UITextViewDelegate {
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var lblText: UILabel!
    @IBOutlet weak var segmentedControl: UISegmentedControl!


//====================
//라이프사이클
//====================
    //로딩 완료시 호출
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //UI
        self.textView.layer.borderColor = UIColor.black.cgColor
        self.textView.layer.borderWidth = 1.0
        self.textView.layer.cornerRadius = 8.0
        self.textView.layer.masksToBounds = true
        
        //자연어 처리 실행
        analyze()
    }
    
    
//====================
//이벤트
//====================
    //세그멘트 컨트롤 변경시 호출
    @IBAction func onValueChanged(sender: UISegmentedControl) {
        //자연어 처리 실행
        analyze()
    }
    
    //텍스트 뷰 완료시 호출
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange,
        replacementText text: String) -> Bool {
        if text == "\n" {
            self.textView.resignFirstResponder()

            //자연어 처리 실행
            analyze()
            return false;
        }
        return true;
    }
    
   
//====================
//자연어 처리
//====================
    //자연어 처리 실행
    func analyze() {
        if self.textView.text == nil || self.textView.text!.isEmpty {return}
        if self.segmentedControl.selectedSegmentIndex == 0 {
            self.language(self.textView.text!)
        } else if self.segmentedControl.selectedSegmentIndex == 1 {
            self.tokenize(self.textView.text!)
        } else if self.segmentedControl.selectedSegmentIndex == 2 {
            self.tagging(self.textView.text!)
        } else if self.segmentedControl.selectedSegmentIndex == 3 {
            self.lemmaization(self.textView.text!)
        } else if self.segmentedControl.selectedSegmentIndex == 4 {
            self.namedEntry(self.textView.text!)
        }
    }

    //(2)언어판정
    func language(_ text: String) {
        //언어판정 실행
        let tagger = NLTagger(tagSchemes: [.language])
        tagger.string = text
        let language = tagger.dominantLanguage!.rawValue
        
        //대응하고 있는 태그 스킴 획득
        let schemes = NLTagger.availableTagSchemes(
            for: .word, language: NLLanguage(rawValue: language))
        var schemesText = "Schemes :\n"
        for scheme in schemes {
            schemesText += "    \(scheme.rawValue)\n"
        }

        //UI 업데이트
        self.lblText.text = "Language : \(language)\n\n\(schemesText)"
    }
    
    //(3)토큰화
    func tokenize(_ text: String) {
        self.lblText.text = ""
        
        //토큰화 준비
        let tokenizer = NLTokenizer(unit: .word)
        tokenizer.string = text
        
        //토큰화 실행
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) {
            tokenRange, _ in
            self.lblText.text = self.lblText.text!+text[tokenRange]+"\n"
            return true
        }
    }
    
    //(4)품사태그 부여
    func tagging(_ text: String) {
        self.lblText.text = ""
        
        //품사태그 부여 준비
        let tagger = NLTagger(tagSchemes: [.lexicalClass])
        tagger.string = text
        
        //품사태크 부여 실행
        let options: NLTagger.Options = [.omitPunctuation, .omitWhitespace]
        tagger.enumerateTags(in: text.startIndex..<text.endIndex,
            unit: .word, scheme: .lexicalClass, options: options) {
            tag, tokenRange in
            self.lblText.text =
                self.lblText.text!+text[tokenRange]+" : "+tag!.rawValue+"\n"
            return true
        }
    }
    
    //(5)표제어추출
    func lemmaization(_ text: String) {
        self.lblText.text = ""
        
        //표제어추출 준비
        let tagger = NLTagger(tagSchemes: [.lemma])
        tagger.string = text
        let options: NLTagger.Options = [.omitPunctuation, .omitWhitespace]
        
        //표제어추출 실행
        tagger.enumerateTags(in: text.startIndex..<text.endIndex,
            unit: .word, scheme: .lemma, options: options) {
            tag, tokenRange in
            if tag != nil {
                self.lblText.text =
                    self.lblText.text!+text[tokenRange]+" : "+tag!.rawValue+"\n"
            }
            return true
        }
    }
    
    //(6)고유표현 추출
    func namedEntry(_ text: String) {
        self.lblText.text = ""
        
        //고유표현 추출준비
        let tagger = NLTagger(tagSchemes: [.nameType])
        tagger.string = text
        let options: NLTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
        
        //고유표현 추출실행
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word,
            scheme: .nameType, options: options) {
            tag, tokenRange in
            let tags: [NLTag] = [.personalName, .placeName, .organizationName]
            if let tag = tag, tags.contains(tag) {
                self.lblText.text =
                    self.lblText.text!+text[tokenRange]+" : "+tag.rawValue+"\n"
            }
            return true
        }
    }
}
