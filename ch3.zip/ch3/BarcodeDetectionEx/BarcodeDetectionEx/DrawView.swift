import UIKit
import Vision

//그리기 뷰
class DrawView: UIView {
    //정수
    let COLOR_BLUE: UIColor = UIColor(red: 0.0, green: 0.0, blue: 255.0, alpha: 0.5)
    let COLOR_WHITE: UIColor = UIColor.white

    //속성
    var imageRect: CGRect = CGRect.zero
    var barcodes: [VNBarcodeObservation]!

    //이미지 크기지정
    func setImageSize(_ imageSize: CGSize) {
        //이미지 표시영역 계산(AspectFill)
        let scale: CGFloat =
            (self.frame.width/imageSize.width > self.frame.height/imageSize.height) ?
            self.frame.width/imageSize.width :
            self.frame.height/imageSize.height
        let dw: CGFloat = imageSize.width*scale
        let dh: CGFloat = imageSize.height*scale
        self.imageRect = CGRect(
            x: (self.frame.width-dw)/2,
            y: (self.frame.height-dh)/2,
            width: dw, height: dh)
    }

    //(3)검출결과 그리기
    override func draw(_ rect: CGRect) {
        if self.barcodes == nil {return}
        
        //그래픽스 컨텍스트 생성
        let context = UIGraphicsGetCurrentContext()!

        //바코드검출 그리기
        for barcode in barcodes {
            //영역그리기
            let rect = convertRect(barcode.boundingBox)
            context.setFillColor(COLOR_BLUE.cgColor)
            context.fill(rect)
            
            //바코드 부가정보 그리기
            drawText(context, text: barcode.payloadStringValue,
                fontSize: 12, rect: rect)
        }
    }
    
    //텍스트 그리기
    func drawText(_ context: CGContext, text: String!, fontSize: CGFloat, rect: CGRect) {
        if text == nil {return}
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributes = [
            NSAttributedString.Key.paragraphStyle: paragraphStyle,
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: fontSize),
            NSAttributedString.Key.foregroundColor: COLOR_WHITE
        ]
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        attributedString.draw(in: rect)
    }
    
    //검출영역의 좌표계를 화면 좌표계로 변환
    func convertRect(_ rect:CGRect) -> CGRect {
        return CGRect(
            x: self.imageRect.minX + rect.minX * self.imageRect.width,
            y: self.imageRect.minY + (1 - rect.maxY) * self.imageRect.height,
            width: rect.width * self.imageRect.width,
            height: rect.height * self.imageRect.height)
    }
}
