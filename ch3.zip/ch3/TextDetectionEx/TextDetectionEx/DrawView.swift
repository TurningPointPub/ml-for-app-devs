import UIKit
import Vision

//그리기 뷰
class DrawView: UIView {
    //정수
    let COLOR_BLUE: UIColor = UIColor(red: 0.0, green: 0.0, blue: 255.0, alpha: 0.3)
    let COLOR_WHITE: UIColor = UIColor.white

    //속성
    var imageRect: CGRect = CGRect.zero
    var texts: [VNTextObservation]!

    //이지미크기 지정
    func setImageSize(_ imageSize: CGSize) {
        //이미지 표시영역 계산(AspectFill)
        let scale: CGFloat =
            (self.frame.width/imageSize.width > self.frame.height/imageSize.height) ?
            self.frame.width/imageSize.width :
            self.frame.height/imageSize.height
        let dw: CGFloat = imageSize.width*scale
        let dh: CGFloat = imageSize.height*scale
        self.imageRect = CGRect(
            x: (self.frame.width-dw)/2,
            y: (self.frame.height-dh)/2,
            width: dw, height: dh)
    }

    //(2)검출결과 그리기
    override func draw(_ rect: CGRect) {
        if self.texts == nil {return}
        
        //그래픽 컨텍스트 생성
        let context = UIGraphicsGetCurrentContext()!

        //텍스트 검출 그리기
        for text in texts {
            //영역 그리기
            let rect = convertRect(text.boundingBox)
            context.setFillColor(COLOR_BLUE.cgColor)
            context.fill(rect)

            //문자별 영영 그리기
            context.setStrokeColor(COLOR_WHITE.cgColor)
            context.setLineWidth(1)
            for box in text.characterBoxes! {
                let rect = convertRect(box.boundingBox)
                context.stroke(rect)
            }
        }
    }
    
    //검출영역 좌표계를 화면 좌표계로 변환
    func convertRect(_ rect:CGRect) -> CGRect {
        return CGRect(
            x: self.imageRect.minX + rect.minX * self.imageRect.width,
            y: self.imageRect.minY + (1 - rect.maxY) * self.imageRect.height,
            width: rect.width * self.imageRect.width,
            height: rect.height * self.imageRect.height)
    }
}
