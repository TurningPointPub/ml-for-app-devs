package net.npaka.custommodelex;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Build;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.common.FirebaseMLException;
import com.google.firebase.ml.custom.FirebaseModelDataType;
import com.google.firebase.ml.custom.FirebaseModelInputOutputOptions;
import com.google.firebase.ml.custom.FirebaseModelInputs;
import com.google.firebase.ml.custom.FirebaseModelInterpreter;
import com.google.firebase.ml.custom.FirebaseModelManager;
import com.google.firebase.ml.custom.FirebaseModelOptions;
import com.google.firebase.ml.custom.FirebaseModelOutputs;
import com.google.firebase.ml.custom.model.FirebaseCloudModelSource;
import com.google.firebase.ml.custom.model.FirebaseLocalModelSource;
import com.google.firebase.ml.custom.model.FirebaseModelDownloadConditions;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//커스텀 모델
public class ViewController extends FrameLayout {
    //UI
    private ImageView imageView;
    private TextView lblText;

    //정보
    private FirebaseModelInterpreter interpreter;
    private String[] labels;


//====================
//Life Cycle
//====================
    //컨스트럭터
    public ViewController(Activity activity) {
        super(activity);

        //모델 초기화
        initModel();

        //레이아웃 
        this.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        LayoutInflater inflater = (LayoutInflater)activity.
            getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.main, null);
        addView(view);

        //UI
        this.imageView = this.findViewById(R.id.image_view);
        this.lblText = this.findViewById(R.id.lbl_text);

        //제스처 추가 
        view.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    showActionSheet();
                }
                return false;
            }
        });

        //액션시트 표시 
        showActionSheet();
    }

    //모델 초기화 
    private void initModel() {
        //(1)라벨 읽어오기
        String text = readAssetsText("labels.txt");
        labels = text.split("\n", 0);

        //(2)클라우드 모델 자동 업데이트 조건생성 
        FirebaseModelDownloadConditions.Builder conditionsBuilder =
            new FirebaseModelDownloadConditions.Builder()
            .requireWifi();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            conditionsBuilder = conditionsBuilder
                .requireCharging()
                .requireDeviceIdle();
        }
        FirebaseModelDownloadConditions conditions = conditionsBuilder.build();

        //(3)클라우드 모델 소스 등록 
        FirebaseCloudModelSource cloudSource =
            new FirebaseCloudModelSource.Builder("image_classification")
            .enableModelUpdates(true)
            .setInitialDownloadConditions(conditions)
            .setUpdatesDownloadConditions(conditions)
            .build();
        FirebaseModelManager.getInstance().registerCloudModelSource(cloudSource);

        //(4)로컬 모델 소스 등록 
        FirebaseLocalModelSource localSource =
            new FirebaseLocalModelSource.Builder("local_image_classification")
            .setAssetFilePath("image_classification.tflite")
            .build();
        FirebaseModelManager.getInstance().registerLocalModelSource(localSource);

        //(5)커스텀 모델 검출기 생성 
        try {
            FirebaseModelOptions options = new FirebaseModelOptions.Builder()
                .setCloudModelName("image_classification")
                .setLocalModelName("local_image_classification")
                .build();
            interpreter = FirebaseModelInterpreter.getInstance(options);
        } catch (FirebaseMLException e) {
            android.util.Log.d("debug",e.getLocalizedMessage());
        }
    }

    //애셋 텍스트 불러오기
    private String readAssetsText(String name) {
        char[] work = new char[1024];
        InputStreamReader in = null;
        try {
            StringBuffer sb = new StringBuffer();
            in = new InputStreamReader(
                getContext().getAssets().open(name));
            while (true) {
                int size = in.read(work);
                if (size <= 0) break;
                sb.append(work, 0, size);
            }
            in.close();
            return sb.toString();
        } catch (Exception e) {
            try {
                if (in != null) in.close();
            } catch (Exception e2) {
            }
            return null;
        }
    }


//====================
//Action Sheet
//====================
    //액션시트 표시 
    private void showActionSheet() {
        String[] items = {"카메라", "사진 라이브러리"};
        new AlertDialog.Builder(this.getContext())
            .setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ((AppDelegate)getContext()).openPicker(which, new AppDelegate.ICompletion(){
                        public void onCompletion(Bitmap image) {
                            if (image == null) return;
                            imageView.setImageBitmap(image);

                            //예측
                            predict(image);
                        }
                    });
                }
            })
            .setNegativeButton("취소", null)
            .show();
    }


//====================
//alert
//====================
    //경고 표시
    private void showAlert(String text) {
        new AlertDialog.Builder(this.getContext())
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show();
    }


//====================
//예측
//====================
    //예측
    private void predict(Bitmap image) {
        try {
            //(6)모델 입력형식과 출력형식 지정 
            FirebaseModelInputOutputOptions inputOutputOptions =
                new FirebaseModelInputOutputOptions.Builder()
                    .setInputFormat(0, FirebaseModelDataType.FLOAT32, new int[]{1, 28, 28, 1})
                    .setOutputFormat(0, FirebaseModelDataType.FLOAT32, new int[]{1, 10})
                    .build();

            //(7)모델 일력데이터 생성 
            float[][][][] input = image2inputData(image, new Point(28, 28));
            FirebaseModelInputs inputs = new FirebaseModelInputs.Builder()
                .add(input)
                .build();

            //(9)예측 실행 
            interpreter.run(inputs, inputOutputOptions)
                //성공시 호출 
                .addOnSuccessListener(
                    new OnSuccessListener<FirebaseModelOutputs>() {
                        @Override
                        public void onSuccess(FirebaseModelOutputs outputs) {
                            //검출결과 획득 
                            float[][] output = outputs.getOutput(0);

                            //outputs을 HashMap으로 교환 
                            Map<Integer, Integer> hashMap = new HashMap<>();
                            float[] inArray = output[0];
                            for (int i = 0; i < inArray.length; i++) {
                                hashMap.put(i, (int)inArray[i]);
                            }

                            //신뢰도순으로 정렬
                            List<Map.Entry<Integer,Integer>> entries =
                                new ArrayList<>(hashMap.entrySet());
                            Collections.sort(entries, new Comparator<Map.Entry<Integer,Integer>>() {
                                @Override
                                public int compare(Map.Entry<Integer,Integer> entry1,
                                    Map.Entry<Integer,Integer> entry2) {
                                    return (entry2.getValue()).compareTo(entry1.getValue());
                                }
                            });
                            String text = "\n";
                            for (int i = 0; i < Math.min(3, entries.size()); i++) { //上位3件
                                Map.Entry<Integer,Integer> s = entries.get(i);
                                int index = s.getKey(); //Index
                                int accuracy = (int)((float)s.getValue()*100f); //信頼度
                                text += String.format("%s : %d%%\n", labels[index], accuracy);
                            }
                            final String str = text;

                            //UI 업데이트 
                            post(new Runnable() {
                                @Override
                                public void run() {
                                    lblText.setText(str);
                                    lblText.setVisibility(
                                        str.length() == 0 ? View.GONE : View.VISIBLE);
                                }
                            });

                        }
                    })
                //에러시 호출 
                .addOnFailureListener(
                    new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            showAlert(e.getMessage());
                        }
                    });
        } catch (FirebaseMLException e) {
            android.util.Log.d("debug",e.getLocalizedMessage());
        }
    }

    //(8)Bitmap를 다차원 배열로 변환 
    private float[][][][] image2inputData(Bitmap image, Point size) {
        //Bitmap 리사이즈와 RGBA를 int 배열로 변환 
        int[] rgbaData = cgImage2rgbaData(image, size);

        //RGBA를 int배열로 그레이 스케일 float 배열로 변환 
        float[][][][] inputData = new float[1][size.y][size.x][1];
        for (int i = 0; i < rgbaData.length; i++) {
            float r = (float)Color.red(rgbaData[i]);
            float g = (float)Color.green(rgbaData[i]);
            float b = (float)Color.blue(rgbaData[i]);
            float gray = r*0.3f+g*0.59f+b*0.11f;
            inputData[0][i/size.x][i%size.x][0] = gray;
        }
        return inputData;
    }

    //Bitmap을 RGBA int배열로 변환 
    private int[] cgImage2rgbaData(Bitmap image, Point size) {
        Bitmap resizeImage = Bitmap.createScaledBitmap(
            image, size.x, size.y, true);
        int[] pixels = new int[size.x*size.y];
        resizeImage.getPixels(pixels, 0, size.x, 0, 0, size.x, size.y);
        return pixels;
    }
}