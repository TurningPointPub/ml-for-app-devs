import UIKit
import FirebaseMLModelInterpreter

//커스텀 모델
class ViewController: UIViewController,
    UINavigationControllerDelegate,
    UIImagePickerControllerDelegate,
    UIGestureRecognizerDelegate {
    //UI
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var lblText: UILabel!
    
    //정보
    var labels: [String]! = nil
    var interpreter: ModelInterpreter! = nil
    

//====================
//라이프 사이클
//====================
    //뷰 로딩시 오출
    override func viewDidLoad() {
        //모델 초기화
        initModel()
    }
    
    //모델 초기화
    func initModel() {
        //(1)라벨 읽어오기
        let filePath = Bundle.main.path(forResource: "labels", ofType: "txt")!
        let text = try? String(contentsOfFile: filePath, encoding: String.Encoding.utf8)
        labels = text?.components(separatedBy: "\n")
        
        //(2)클라우드 모델 자동 업데이트 조건 생성
        let conditions = ModelDownloadConditions(
            isWiFiRequired: true,
            canDownloadInBackground: true)
        
        //(3)클라우드 모델 소스 등록
        let cloudModelSource = CloudModelSource(
            modelName: "image_classification",
            enableModelUpdates: true,
            initialConditions: conditions,
            updateConditions: conditions
        )
        if !ModelManager.modelManager()
            .register(cloudModelSource) {return}
        
        //(4)로컬 모델소스 등록
        let modelPath = Bundle.main.path(
            forResource: "image_classification",
            ofType: "tflite")
        let localModelSource = LocalModelSource(
            modelName: "local_image_classification",
            path: modelPath!)
        if !ModelManager.modelManager()
            .register(localModelSource) {return}
        
        //(5)커스텀모델 검출기 생성
        let options = ModelOptions(
            cloudModelName: "image_classification",
            localModelName: "local_image_classification"
        )
        self.interpreter = ModelInterpreter.modelInterpreter(options: options)
    }
    
    //뷰 표시시에 호출
    override func viewDidAppear(_ animated: Bool) {
        //액션시트 표시
        if self.imageView.image == nil {
            showActionSheet()
        }
    }
    
    
//====================
//이벤트
//====================
    //화면 터치시 호출
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        showActionSheet()
    }
   

//====================
//액션시트
//====================
    //액션시트 표시
    func showActionSheet() {
        let actionSheet = UIAlertController(title: nil, message: nil,
            preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "카메라", style: .default) {
            action in
            self.openPicker(sourceType: .camera)
        })
        actionSheet.addAction(UIAlertAction(title: "사진 라이브러리", style: .default) {
            action in
            self.openPicker(sourceType: .photoLibrary)
        })
        actionSheet.addAction(UIAlertAction(title: "취소", style: .cancel))
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
//====================
//경고
//====================
    //경고표시
    func showAlert(_ text: String!) {
        let alert = UIAlertController(title: text, message: nil,
            preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",
            style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
   
   
//====================
//이미지피커
//====================
    //이미지피커 열기
    func openPicker(sourceType: UIImagePickerController.SourceType) {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }

    //이미지피커의 이미지 획득시 호출
    func imagePickerController(_ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //이미지 지정
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        self.imageView.image = image
        
        //닫기
        picker.presentingViewController!.dismiss(animated:true, completion:nil)

        //예측
        predict(image)
    }
    
    //이미지피커 취소시 호출
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        //닫기
        picker.presentingViewController!.dismiss(animated:true, completion:nil)
    }
    
    
//====================
//예측
//====================
    //예측
    func predict(_ image: UIImage!) {
        DispatchQueue.global(qos: .default).async {
            //(6)모델 입력형식과 출력형식 지정
            let ioOptions = ModelInputOutputOptions()
            do {
                try ioOptions.setInputFormat(index: 0, type: .float32, dimensions: [1, 28, 28, 1])
                try ioOptions.setOutputFormat(index: 0, type: .float32, dimensions: [1, 10])
            } catch let error as NSError {
                print(error.localizedDescription)
                return
            }
            
            //(7)모델 입력 데이터 지정
            let data: Data = self.image2inputData(image,
                size: CGSize(width:28, height:28))!
            let input = ModelInputs()
            do {
                try input.addInput(data)
            } catch let error as NSError {
                print(error.localizedDescription)
                return
            }
            
            //(9)예측실행
            self.interpreter.run(inputs: input, options: ioOptions) {
                outputs, error in
                //에러처리
                if error != nil {
                    self.showAlert(error!.localizedDescription)
                    return
                }

                //검출결과 획득
                let outputs = try? outputs?.output(index: 0)
                if (outputs == nil) {return}
                
                //outputs을 enumerate로 변환
                let inArray = (outputs as! NSArray)[0] as! NSArray
                
                let count = inArray.count
                var outArray = [Float32]()
                for r in 0..<count {
                    outArray.append(Float32(truncating: inArray[r] as! NSNumber))
                }
                let enumerate = outArray.enumerated()

                //신뢰도순으로 정렬
                let sorted = enumerate.sorted(by: {$0.element > $1.element})
                var text: String = "\n"
                for i in 0..<min(3, sorted.count) { //상위 3건
                    let index = sorted[i].offset //Index
                    let accuracy = Int(sorted[i].element*100.0) //신뢰도
                    text += String(format:"%@ : %d%%\n", self.labels[index], accuracy)
                }
                
                //UI 업데이트
                DispatchQueue.main.async {
                    self.lblText.text = text
                }
            }
        }
    }
    
    //(8)UIImage를 다차원 배열로 변환
    func image2inputData(_ image: UIImage, size: CGSize) -> Data? {
        let cgImage = image.cgImage!
        
        //CGImage의 리사이즈와 RGBA Data로의 변환
        let rgbaData = self.cgImage2rgbaData(cgImage, size: size)!

        //RGBA Data를 그레이 스케일 Data로 변환
        var r: Float = 0
        var g: Float = 0
        var b: Float = 0
        let inputData = NSMutableData()
        for pixel in rgbaData.enumerated() {
            if (pixel.offset % 4) == 0 {r = Float(pixel.element)}
            if (pixel.offset % 4) == 1 {g = Float(pixel.element)}
            if (pixel.offset % 4) == 2 {
                b = Float(pixel.element)
                var gray: Float32 = Float32(r*0.3+g*0.59+b*0.11)
                inputData.append(Data(bytes: &gray, count:4))
            }
        }
        return inputData as Data
    }
  
    //CGImage 리사이즈와 RGBA Data로의 변환
    func cgImage2rgbaData(_ image: CGImage, size: CGSize) -> Data? {
        let bitmapInfo = CGBitmapInfo(rawValue:
            CGBitmapInfo.byteOrder32Big.rawValue | //32bitのbig endian
            CGImageAlphaInfo.premultipliedLast.rawValue //A가 최하위bit
        )
        let context = CGContext(
            data: nil,
            width: Int(size.width),
            height: Int(size.height),
            bitsPerComponent: image.bitsPerComponent,
            bytesPerRow: 4*Int(size.width),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: bitmapInfo.rawValue)
        if (context == nil) {return nil}
        context!.draw(image, in: CGRect(x: 0, y: 0,
            width: Int(size.width), height: Int(size.height)))
        return context!.makeImage()?.dataProvider?.data as Data?
    }
}
