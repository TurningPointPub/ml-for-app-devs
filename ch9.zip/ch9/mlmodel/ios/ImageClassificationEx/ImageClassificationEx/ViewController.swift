import UIKit
import CoreML
import Vision

//화상분류（사진）
class ViewController: UIViewController,
    UINavigationControllerDelegate,
    UIImagePickerControllerDelegate,
    UIGestureRecognizerDelegate {
    //UI
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var lblText: UILabel!
    
    //(2)모델생성
    var model = try! VNCoreMLModel(for: image_classification().model)
    

//====================
//라이프 사이클
//====================
    //뷰 표시할때 호출
    override func viewDidAppear(_ animated: Bool) {
        //액션시트 표시
        if self.imageView.image == nil {
            showActionSheet()
        }
    }
    
    
//====================
//이벤트
//====================
    //화면터치시 호출
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        showActionSheet()
    }


//====================
//액션시트
//====================
    //액션시트 표시
    func showActionSheet() {
        let actionSheet = UIAlertController(title: nil, message: nil,
            preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default) {
            action in
            self.openPicker(sourceType: .camera)
        })
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default) {
            action in
            self.openPicker(sourceType: .photoLibrary)
        })
        actionSheet.addAction(UIAlertAction(title: "cancel", style: .cancel))
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
//====================
//경고
//====================
    //경고표시
    func showAlert(_ text: String!) {
        let alert = UIAlertController(title: text, message: nil,
            preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",
            style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
   
   
//====================
//(1)이미지 피커
//====================
    //이미지 피커열기
    func openPicker(sourceType: UIImagePickerController.SourceType) {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }

    //이미지 피커 이미지 획득시 호출
    func imagePickerController(_ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //이미지 지정
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        self.imageView.image = image
        
        //닫기
        picker.presentingViewController!.dismiss(animated:true, completion:nil)

        //예측
        predict(image)
    }
    
    //이미지 피커 캔슬시 호출
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        //닫기
        picker.presentingViewController!.dismiss(animated:true, completion:nil)
    }
    
    
//====================
//화상분류
//====================
    //(3)예측
    func predict(_ image: UIImage) {
        DispatchQueue.global(qos: .default).async {
            //(4)요청생성
            let request = VNCoreMLRequest(model: self.model) {
                request, error in //(9)
                //(10)에러처리
                if error != nil {
                    self.showAlert(error!.localizedDescription)
                    return
                }
                
                //(11)검출결과 획득
                let observations = request.results as! [VNClassificationObservation]
                for i in 0..<observations.count {
                    print("\(observations[i].identifier)>>>>\(observations[i].confidence)")
                }


                var text: String = "\n"
                for i in 0..<min(3, observations.count) { //상위3건
                    let probabillity = Int(observations[i].confidence*100) //신뢰도
                    let label = observations[i].identifier //라벨
                    text += "\(label) : \(probabillity)%\n"
                }
                
                //UI업데이트
                DispatchQueue.main.async {
                    self.lblText.text = text
                }
            }
            
            //(5)입력화상 리사이즈 지정
            request.imageCropAndScaleOption = .centerCrop

            //(6)UIImage를 CIImage로 변환
            let ciImage = CIImage(image: image)!
            
            //(7)화상방향 획득
            let orientation = CGImagePropertyOrientation(
                rawValue: UInt32(image.imageOrientation.rawValue))!
         
            //(8)핸들생성과 실행
            let handler = VNImageRequestHandler(
                ciImage: ciImage, orientation: orientation)
            guard (try? handler.perform([request])) != nil else {return}
        }
    }
}
