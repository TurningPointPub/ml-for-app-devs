package net.npaka.captureclassificationex;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.PermissionChecker;
import android.view.Window;

//AppDelegate
public class AppDelegate extends Activity {
    //퍼미션
    private final static int REQUEST_PERMISSONS = 0;
    private final static String[] PERMISSIONS = {
        Manifest.permission.CAMERA};
    private boolean permissionGranted = false;

    //뷰 콘트롤러
    private ViewController viewController;


//====================
//라이프사이클
//====================
    //앱 기동시 호출
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        viewController = new ViewController(this);
        setContentView(viewController);

        //유저 이용허가 확인
        checkPermissions();
    }

    //앱 재개시 호출
    protected void onRestart() {
        super.onRestart();
        if (permissionGranted) {
            viewController.startCamera();
        }
    }

    //앱 정지시 호출
    protected void onStop() {
        super.onStop();
        viewController.stopCamera();
    }


//====================
//퍼미션
//====================
    //유저 이용허가 확인
    private void checkPermissions() {
        //허가
        if (isGranted()) {
            permissionGranted = true;
            viewController.initCapture();
        }
        //미허가
        else {
            //허가 다이얼로그 표시
            ActivityCompat.requestPermissions(this, PERMISSIONS,
                REQUEST_PERMISSONS);
        }
    }

    //유저 이용허가 완료여부 확인 
    private boolean isGranted() {
        for (int i  = 0; i < PERMISSIONS.length; i++) {
            if (PermissionChecker.checkSelfPermission(
                AppDelegate.this, PERMISSIONS[i]) !=
                PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    //허가 다이얼로그 선택시 호출 
    @Override
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] results) {
        if (requestCode == REQUEST_PERMISSONS) {
            permissionGranted = true;
            viewController.initCapture();
        } else {
            super.onRequestPermissionsResult(
                requestCode, permissions, results);
        }
    }
}