package net.npaka.barcodedetectionex;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.NonNull;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcode;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetector;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetectorOptions;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.common.FirebaseVisionImageMetadata;

import java.util.Arrays;
import java.util.List;

//바코드 검출
public class ViewController extends FrameLayout {
    //정수
    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();
    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }

    //UI
    private TextureView textureView;
    private DrawView drawView;

    //카메라
    private Activity activity;
    private CameraManager manager;
    private Handler workHandler;
    private String cameraId;
    private CameraCharacteristics cameraInfo;
    private CameraDevice camera;
    private Size previewSize;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader imageReader;
    private Surface surface;

    //정보
    private boolean predictFlag = false;


//====================
//라이프사이클
//====================
    //컨스트럭터
    public ViewController(Activity activity) {
        super(activity);
        this.activity = activity;

        //레이아웃
        this.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        LayoutInflater inflater = (LayoutInflater)activity.
            getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.main, null);
        addView(view);

        //UI
        this.textureView = this.findViewById(R.id.texture_view);
        this.drawView = this.findViewById(R.id.draw_view);
    }

    //카메라캡처 초기화
    public void initCapture() {
        //핸들러 생성
        HandlerThread thread = new HandlerThread("work");
        thread.start();
        this.workHandler = new Handler(thread.getLooper());

        //카메라 매니저 획득
        this.manager = (CameraManager)activity
            .getSystemService(Context.CAMERA_SERVICE);

        //텍스처 뷰 리스터 지정
        this.textureView.setSurfaceTextureListener(
            new TextureView.SurfaceTextureListener() {
            //텍스처 유효화시 호출
            @Override
            public void onSurfaceTextureAvailable(
                SurfaceTexture surface, int width, int height) {
                startCamera();
            }

            //텍스처 크기 변경시 호출
            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surface,
                int width, int height) {
            }

            //텍스처 업데이트시 호출
            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surface) {
            }

            //텍스처 파괴시 호출 
            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
                stopCamera();
                return true;
            }
        });

        //카메라 시작
        if (this.textureView.isAvailable()) startCamera();
    }

    //카메라 시작
    public void startCamera() {
        if (this.camera != null) return;
        try {
            //카메라 정보 획득 
            this.cameraId = getCameraId();
            this.cameraInfo = manager.getCameraCharacteristics(this.cameraId);
            this.previewSize = getPreviewSize(this.cameraInfo);

            //카메라 영상 크기
            int sw = Math.min(previewSize.getWidth(), previewSize.getHeight());
            int sh = Math.max(previewSize.getWidth(), previewSize.getHeight());
            float scale =
                ((float)getWidth()/(float)sw > (float)getHeight()/(float)sh) ?
                (float)getWidth()/(float)sw : (float)getHeight()/(float)sh;
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(sw, sh);
            params.addRule(RelativeLayout.CENTER_IN_PARENT);
            textureView.setLayoutParams(params);
            textureView.setScaleX(scale);
            textureView.setScaleY(scale);

            //카메라 열기
            this.manager.openCamera(this.cameraId, new CameraDevice.StateCallback() {
                //접속시 호출
                @Override
                public void onOpened(CameraDevice camera) {
                    ViewController.this.camera = camera;
                    initPreview();
                    startPreview();
                }

                //접속종료시 호출
                @Override
                public void onDisconnected(CameraDevice camera) {
                    stopCamera();
                }

                //에러시 호출
                @Override
                public void onError(CameraDevice camera, int error) {
                    stopCamera();
                }
            }, null);
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //카메라 정지
    public void stopCamera() {
        if (this.camera == null) return;
        this.camera.close();
        this.camera = null;
    }

    //카메라 ID 획득
    private String getCameraId() {
        try {
            for (String cameraId : manager.getCameraIdList()) {
                CameraCharacteristics cameraInfo =
                    manager.getCameraCharacteristics(cameraId);
                //후방 카메라
                if (cameraInfo.get(CameraCharacteristics.LENS_FACING) ==
                    CameraCharacteristics.LENS_FACING_BACK) {
                    return cameraId;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //프리뷰 크기 획득
    private Size getPreviewSize(CameraCharacteristics characteristics) {
        StreamConfigurationMap map = characteristics.get(
            CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] sizes = map.getOutputSizes(SurfaceTexture.class);
        for (int i = 0; i < sizes.length; i++) {
            //크기 1000x1000 이하 
            if (sizes[i].getWidth() < 1000 && sizes[i].getHeight() < 1000) {
                return sizes[i];
            }
        }
        return sizes[0];
    }

    //프리뷰 초기화
    private void initPreview() {
        if (this.camera == null) return;

        //출력장소 텍스처 생성
        SurfaceTexture texture = this.textureView.getSurfaceTexture();
        if (texture == null) return;
        texture.setDefaultBufferSize(this.previewSize.getWidth(), this.previewSize.getHeight());
        this.surface = new Surface(texture);

        //출력장소 이미지 리더 생성
        this.imageReader = ImageReader.newInstance(
            this.previewSize.getWidth(), this.previewSize.getHeight(),
            ImageFormat.JPEG, 10);
        this.imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                try {
                    //예측
                    Image image = reader.acquireLatestImage();
                    detectLabels(image);
                    image.close();
                } catch (Exception e) {
                    //무처리
                }
            }
        }, workHandler);

        //프리뷰 빌더 생성
        try {
            this.previewBuilder = this.camera
                .createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            this.previewBuilder.addTarget(surface);
            this.previewBuilder.addTarget(imageReader.getSurface());
            this.previewBuilder.set(CaptureRequest.JPEG_ORIENTATION, getOrientation());
            this.previewBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            this.previewBuilder.set(CaptureRequest.CONTROL_AE_MODE,
                CaptureRequest.CONTROL_AE_MODE_ON);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    //회전 획득
    private int getOrientation() {
        try {
            //디스플레이 방향
            int deviceRotation = activity.getWindowManager().getDefaultDisplay().getRotation();
            int rotation = ORIENTATIONS.get(deviceRotation);

            //렌즈 방향
            CameraManager cameraManager =
                (CameraManager)activity.getSystemService(Activity.CAMERA_SERVICE);
            int sensorOrientation = cameraManager
                .getCameraCharacteristics(this.cameraId)
                .get(CameraCharacteristics.SENSOR_ORIENTATION);

            //회전
            return (rotation + sensorOrientation + 270) % 360;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    //프리뷰 시작
    private void startPreview() {
        if (this.camera == null) return;
        try {
            //프리뷰 시작
            this.camera.createCaptureSession(Arrays.asList(surface, imageReader.getSurface()),
                new CameraCaptureSession.StateCallback() {
                    //성공시 호출
                    @Override
                    public void onConfigured(CameraCaptureSession session) {
                        if (ViewController.this.camera == null) return;

                        //카메라영상 텍스처 표시
                        try {
                            session.setRepeatingRequest(
                                ViewController.this.previewBuilder.build(),
                                null,
                                ViewController.this.workHandler);
                        } catch (CameraAccessException e) {
                            e.printStackTrace();
                        }
                    }

                    //실패시 호출
                    @Override
                    public void onConfigureFailed(CameraCaptureSession session) {
                    }
                }, this.workHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }


//====================
//경고
//====================
    //경고표시
    private void showAlert(String text) {
        new AlertDialog.Builder(this.getContext())
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show();
    }


//====================
//바코드 검출
//====================
    //온디바이스 API 바코드 검출
    private void detectLabels(Image image) {
        //이미지 크기 지정
        int sw = Math.min(image.getWidth(), image.getHeight());
        int sh = Math.max(image.getWidth(), image.getHeight());
        drawView.setImageSize(sw, sh);

        //검출중 다음 검출 대기
        if (this.predictFlag) return;
        this.predictFlag = true;

        //FirebaseVisionImage 생성
        FirebaseVisionImage visionImage = FirebaseVisionImage.fromMediaImage(
            image, FirebaseVisionImageMetadata.ROTATION_0);

        //(1)바코드 검출 옵션 생성
        FirebaseVisionBarcodeDetectorOptions options =
            new FirebaseVisionBarcodeDetectorOptions.Builder()
                .setBarcodeFormats(FirebaseVisionBarcode.FORMAT_ALL_FORMATS)
                .build();

        //(2)바코드 검출 검출기 생성
        FirebaseVisionBarcodeDetector barcodeDetector = FirebaseVision.getInstance()
            .getVisionBarcodeDetector(options);

        //(3)바코드 검출 실행
        barcodeDetector.detectInImage(visionImage)
            .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionBarcode>>() {
                @Override
                public void onSuccess(final List<FirebaseVisionBarcode> barcodes) {
                    post(new Runnable() {
                        @Override
                        public void run() {
                            //검출결과 획득
                            drawView.barcodes = barcodes;

                            //UI 갱신
                            drawView.postInvalidate();
                            predictFlag = false;
                        }
                    });
                }
            })
            .addOnFailureListener(new OnFailureListener() {
                //에러시에 호출
                @Override
                public void onFailure(@NonNull Exception e) {
                    showAlert(e.getMessage());
                    predictFlag = false;
                }
            });
    }
}