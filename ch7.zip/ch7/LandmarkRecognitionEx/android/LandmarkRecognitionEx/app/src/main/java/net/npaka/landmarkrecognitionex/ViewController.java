package net.npaka.landmarkrecognitionex;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.cloud.FirebaseVisionCloudDetectorOptions;
import com.google.firebase.ml.vision.cloud.landmark.FirebaseVisionCloudLandmark;
import com.google.firebase.ml.vision.cloud.landmark.FirebaseVisionCloudLandmarkDetector;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;

import java.util.List;

//랜드마크 인식
public class ViewController extends FrameLayout {
    //UI
    private ImageView imageView;
    private TextView lblText;


//====================
//라이프사이클
//====================
    //컨스트럭터
    public ViewController(Activity activity) {
        super(activity);

        //레이아웃
        this.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        LayoutInflater inflater = (LayoutInflater)activity.
            getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.main, null);
        addView(view);

        //UI
        this.imageView = this.findViewById(R.id.image_view);
        this.lblText = this.findViewById(R.id.lbl_text);

        //제스처 추가
        view.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    showActionSheet();
                }
                return false;
            }
        });

        //액션시트 표시
        showActionSheet();
    }


//====================
//액션시트
//====================
    //액션시트 표시
    private void showActionSheet() {
        String[] items = {"カメラ", "フォトライブラリ"};
        new AlertDialog.Builder(this.getContext())
            .setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ((AppDelegate)getContext()).openPicker(which, new AppDelegate.ICompletion(){
                        public void onCompletion(Bitmap image) {
                            if (image == null) return;
                            imageView.setImageBitmap(image);

                            //예측
                            detectLandmarks(image);
                        }
                    });
                }
            })
            .setNegativeButton("キャンセル", null)
            .show();
    }


//====================
//경고
//====================
    //경고 표시
    private void showAlert(String text) {
        new AlertDialog.Builder(this.getContext())
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show();
    }


//====================
//랜드마크 인식
//====================
    //클라우드API 랜드마크 인식
    private void detectLandmarks(Bitmap image) {
        //FirebaseVisionImageの生成
        FirebaseVisionImage visionImage = FirebaseVisionImage.fromBitmap(image);

        //(1)랜드마크 인식 옵션 생성
        FirebaseVisionCloudDetectorOptions options =
            new FirebaseVisionCloudDetectorOptions.Builder()
                .setModelType(FirebaseVisionCloudDetectorOptions.LATEST_MODEL)
                .setMaxResults(20)
                .build();

        //(2)랜드마크 인식 검출기 생성
        FirebaseVisionCloudLandmarkDetector landmarkDetector = FirebaseVision.getInstance()
            .getVisionCloudLandmarkDetector(options);

        //(3)랜드마크 인식 실행
        landmarkDetector.detectInImage(visionImage)
            .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionCloudLandmark>>() {
                //성공시 호출
                @Override
                public void onSuccess(List<FirebaseVisionCloudLandmark> landmarks) {
                    //검증결과 획득
                    String text = "\n";
                    for (FirebaseVisionCloudLandmark landmark: landmarks) {
                        text += landmark.getLandmark()+" : "+
                            (int)(landmark.getConfidence()*100)+"%\n";
                    }
                    final String str = text;

                    //UI 업데이트
                    post(new Runnable() {
                        @Override
                        public void run() {
                            lblText.setText(str);
                            lblText.setVisibility(
                                str.length() == 0 ? View.GONE : View.VISIBLE);
                        }
                    });
                }
            })
            .addOnFailureListener(new OnFailureListener() {
                //에러시 호출
                @Override
                public void onFailure(@NonNull Exception e) {
                    showAlert(e.getMessage());
                }
            });
    }
}