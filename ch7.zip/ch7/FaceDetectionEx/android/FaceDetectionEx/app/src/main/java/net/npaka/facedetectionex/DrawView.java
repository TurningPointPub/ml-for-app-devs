package net.npaka.facedetectionex;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;

import com.google.firebase.ml.vision.face.FirebaseVisionFace;
import com.google.firebase.ml.vision.face.FirebaseVisionFaceLandmark;

import java.util.List;

//그리기 뷰
public class DrawView extends View {
    //정수
    private static final int COLOR_BLUE = Color.argb(127, 0, 0, 255);
    private static final int COLOR_WHITE = Color.WHITE;

    //정보
    private Rect imageRect = new Rect();
    private float imageScale = 1;
    public List<FirebaseVisionFace> faces = null;
    private float density;
    private Paint paint;


//====================
//라이프사이클
//====================
    //컨스트럭터
    public DrawView(Context context) {
        super(context);
        init();
    }

    //컨스트럭터
    public DrawView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    //컨스트럭터
    public DrawView(Context context, AttributeSet attrs,
        int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    //초기화
    private void init() {
        DisplayMetrics metrics = getContext().getResources().getDisplayMetrics();
        density = metrics.density;
        paint = new Paint();
    }


//====================
//액세스
//====================
    //이미지 크기지정
    public void setImageSize(int imageWidth, int imageHeight) {
        //이미지 표시영역 계산(AspectFill)
        float scale =
            ((float)getWidth()/(float)imageWidth > (float)getHeight()/(float)imageHeight) ?
            (float)getWidth()/(float)imageWidth :
            (float)getHeight()/(float)imageHeight;
        float dw = imageWidth*scale;
        float dh = imageHeight*scale;
        this.imageRect = new Rect(
            (int)((getWidth()-dw)/2),
            (int)((getHeight()-dh)/2),
            (int)((getWidth()-dw)/2+dw),
            (int)((getHeight()-dh)/2+dh));
        this.imageScale = scale;
    }


//====================
//검출결과 그리기
//====================
    //(5)검출결과 그리기
    @Override
    protected void onDraw(Canvas canvas) {
        if (this.faces == null) return;

        //얼굴검출 그리기
        for (FirebaseVisionFace face : this.faces) {
            //영역 그리기 
            Rect rect = convertRect(face.getBoundingBox());
            paint.setColor(COLOR_BLUE);
            paint.setStrokeWidth(2*density);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawRect(rect, paint);

            //얼굴 랜드마크 그리기
            paint.setColor(COLOR_WHITE);
            drawLandmark(canvas, face, FirebaseVisionFaceLandmark.LEFT_EYE);
            drawLandmark(canvas, face, FirebaseVisionFaceLandmark.RIGHT_EYE);
            drawLandmark(canvas, face, FirebaseVisionFaceLandmark.LEFT_MOUTH);
            drawLandmark(canvas, face, FirebaseVisionFaceLandmark.RIGHT_MOUTH);
            drawLandmark(canvas, face, FirebaseVisionFaceLandmark.BOTTOM_MOUTH);

            //웃는 얼굴 확률 표시
            if (face.getSmilingProbability() != FirebaseVisionFace.UNCOMPUTED_PROBABILITY) {
                String text = String.format("%d%%", (int)(face.getSmilingProbability()*100));
                drawText(canvas, text, rect);
            }
        }
    }

    //얼굴 랜드마크 그리기
    private void drawLandmark(Canvas canvas, FirebaseVisionFace face, int type) {
        FirebaseVisionFaceLandmark landmark = face.getLandmark(type);
        if (landmark != null) {
            Point point = convertPoint(new Point(
                landmark.getPosition().getX().intValue(),
                landmark.getPosition().getY().intValue()));
            paint.setColor(COLOR_WHITE);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(point.x, point.y, 3 * density, paint);
        }
    }

    //텍스트 그리기
    private void drawText(Canvas canvas, String text, Rect rect) {
        if (text == null) return;
        //배경
        Rect textRect = new Rect(rect.left, (int)(rect.top-16*density),
            rect.left+rect.width(), rect.top);
        paint.setColor(COLOR_BLUE);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(textRect, paint);

        //텍스트
        paint.setColor(COLOR_WHITE);
        paint.setTextSize(16*density);
        Paint.FontMetrics metrics = paint.getFontMetrics();
        canvas.save();
        canvas.clipRect(textRect);
        canvas.drawText(text,
            (int)(textRect.left+(textRect.width()-paint.measureText(text))/2),
            textRect.top-metrics.ascent, paint);
        canvas.restore();
    }

    //검출결과 좌표계를 화면 좌표계로 변환 
    private Rect convertRect(Rect rect) {
        return new Rect(
            (int)(imageRect.left+rect.left*imageScale),
            (int)(imageRect.top+rect.top*imageScale),
            (int)(imageRect.left+rect.left*imageScale+rect.width()*imageScale),
            (int)(imageRect.top+rect.top*imageScale+rect.height()*imageScale));
    }

    //검출결과 좌표계를 화면 좌표계로 변환 
    private Point convertPoint(Point point) {
        return new Point(
            (int)(imageRect.left+point.x*imageScale),
            (int)(imageRect.top+point.y*imageScale));
    }
}