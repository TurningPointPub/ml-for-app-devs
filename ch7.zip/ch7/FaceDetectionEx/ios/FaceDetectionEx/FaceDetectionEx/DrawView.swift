import UIKit
import FirebaseMLVision

//그리기 뷰
class DrawView: UIView {
    //정수
    let COLOR_BLUE: UIColor = UIColor(red: 0.0, green: 0.0, blue: 255.0, alpha: 0.5)
    let COLOR_WHITE: UIColor = UIColor.white

    //속성
    var imageRect: CGRect = CGRect.zero
    var imageScale: CGFloat = 1
    var faces: [VisionFace]! = nil

    //초기화
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    //초기화
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }

    //이미지 크기지정
    func setImageSize(_ imageSize: CGSize) {
        //이미지 표시영역 계산(AspectFill)
        let scale: CGFloat =
            (self.frame.width/imageSize.width > self.frame.height/imageSize.height) ?
            self.frame.width/imageSize.width :
            self.frame.height/imageSize.height
        let dw: CGFloat = imageSize.width*scale
        let dh: CGFloat = imageSize.height*scale
        self.imageRect = CGRect(
            x: (self.frame.width-dw)/2,
            y: (self.frame.height-dh)/2,
            width: dw, height: dh)
        self.imageScale = scale
    }

    //(5)검출결과 그리기
    override func draw(_ rect: CGRect) {
        if self.faces == nil {return}
        
        //그래픽 컨텍스트 생성
        let context = UIGraphicsGetCurrentContext()!
        
        //얼굴검출 그리기
        for face in self.faces {
            //영역 그리기
            let rect = convertRect(face.frame)
            context.setStrokeColor(COLOR_BLUE.cgColor)
            context.setLineWidth(2)
            context.stroke(rect)

            //랜드마크 그리기
            context.setFillColor(COLOR_WHITE.cgColor)
            drawLandmark(context, face: face, type: .leftEye)
            drawLandmark(context, face: face, type: .rightEye)
            drawLandmark(context, face: face, type: .mouthLeft)
            drawLandmark(context, face: face, type: .mouthRight)
            drawLandmark(context, face: face, type: .mouthBottom)

            //웃는얼굴 확률 표시
            if face.hasSmilingProbability {
                let text = String(format:"%d%%",Int(face.smilingProbability*100))
                drawText(context, text: text, rect: rect)
            }
        }
    }
    
    //랜드마크 그리기
    func drawLandmark(_ context: CGContext, face: VisionFace, type: FaceLandmarkType) {
        if let landmark = face.landmark(ofType: type) {
            let point = convertPoint(CGPoint(
                x: landmark.position.x.intValue,
                y: landmark.position.y.intValue))
            context.fillEllipse(in: CGRect(
                x: point.x-3,
                y: point.y-3,
                width: 6, height: 6))
        }
    }
    
    //텍스트 그리기
    func drawText(_ context: CGContext, text: String, rect: CGRect) {
        //배경
        let textRect = CGRect(x: rect.minX, y: rect.minY-16,
            width: rect.width, height: 16)
        context.setFillColor(COLOR_BLUE.cgColor)
        context.fill(textRect)

        //텍스트
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributes = [
            NSAttributedString.Key.paragraphStyle: paragraphStyle,
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 16),
            NSAttributedString.Key.foregroundColor: UIColor.white
        ]
        let attributedString = NSAttributedString(
            string: text, attributes: attributes)
        attributedString.draw(in: textRect)
    }
    
    //검출결과 좌표계를 화면 좌표계로 변환
    func convertRect(_ rect: CGRect) -> CGRect {
        return CGRect(
            x: Int(imageRect.minX+rect.minX*imageScale),
            y: Int(imageRect.minY+rect.minY*imageScale),
            width: Int(rect.width*imageScale),
            height: Int(rect.height*imageScale))
    }

    //검출결과 좌표계를 화면 좌표계로 변환
    func convertPoint(_ point: CGPoint) -> CGPoint {
        return CGPoint(
            x: Int(imageRect.minX+point.x*imageScale),
            y: Int(imageRect.minY+point.y*imageScale))
    }
}
