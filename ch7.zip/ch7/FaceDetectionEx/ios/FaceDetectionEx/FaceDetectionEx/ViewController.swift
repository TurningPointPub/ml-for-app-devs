import UIKit
import AVFoundation
import FirebaseMLVision

//얼굴검출
class ViewController: UIViewController,
    AVCaptureVideoDataOutputSampleBufferDelegate {
    //UI
    @IBOutlet weak var drawView: DrawView!
    var previewLayer: AVCaptureVideoPreviewLayer!


//====================
//라이프사이클
//====================
    //뷰 표시시 호출
    override func viewDidAppear(_ animated: Bool) {
        //카메라캡처 시작
        startCapture()
    }

    
//====================
//경고
//====================
    //경고표시
    func showAlert(_ text: String!) {
        let alert = UIAlertController(title: text, message: nil,
            preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",
            style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
//====================
//카메라캡처
//====================
    //카메라캡처 시작
    func startCapture() {
        //세션 초기화
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = AVCaptureSession.Preset.photo

        //입력지정
        let captureDevice: AVCaptureDevice! = self.device(false)
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else {return}
        guard captureSession.canAddInput(input) else {return}
        captureSession.addInput(input)
        
        //출력지정
        let output: AVCaptureVideoDataOutput = AVCaptureVideoDataOutput()
        output.setSampleBufferDelegate(self, queue: DispatchQueue(label: "VideoQueue"))
        guard captureSession.canAddOutput(output) else {return}
        captureSession.addOutput(output)
        let videoConnection = output.connection(with: AVMediaType.video)
        videoConnection!.videoOrientation = .portrait

        //프리뷰 지정
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        previewLayer.frame = self.drawView.frame
        self.view.layer.insertSublayer(previewLayer, at: 0)

        //카메라캡처 시작
        captureSession.startRunning()
    }
    
    //디바이스 획득
    func device(_ frontCamera: Bool) -> AVCaptureDevice! {
        let position: AVCaptureDevice.Position = frontCamera ? .front : .back
        let deviceDiscoverySession = AVCaptureDevice.DiscoverySession(
            deviceTypes: [AVCaptureDevice.DeviceType.builtInWideAngleCamera],
            mediaType: AVMediaType.video,
            position: AVCaptureDevice.Position.unspecified)
        let devices = deviceDiscoverySession.devices
        for device in devices {
            if device.position == position {
                return device
            }
        }
        return nil
    }

    //카메라캡처 획득시 호출
    func captureOutput(_ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection) {
        //예측
        detecteFace(sampleBuffer)
    }
    
    
//====================
//얼굴검출
//====================
    //온디바이스API 얼굴검출
    func detecteFace(_ sampleBuffer: CMSampleBuffer) {
        //(1)화면크기 지정
        let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)
        self.drawView.setImageSize(CGSize(
            width: CGFloat(CVPixelBufferGetWidth(imageBuffer!)),
            height: CGFloat(CVPixelBufferGetHeight(imageBuffer!))))
        
        //VisionImage 생성
        let visionImage = VisionImage(buffer: sampleBuffer)

        //(2)얼굴검출 옵션 생성
        let options = VisionFaceDetectorOptions()
        options.landmarkType = .all
        options.classificationType = .all
        options.modeType = .accurate
    
        //(3)얼굴검출 검출기 생성
        let faceDetector = Vision.vision().faceDetector(options: options)
        
        //(4)얼굴검출 실행
        faceDetector.detect(in: visionImage) {
            faces, error in
            //에러처리
            if error != nil {
                self.showAlert(error!.localizedDescription)
                return
            }
            
            DispatchQueue.main.async {
                //검출결과 획득
                self.drawView.faces = faces
                
                //UI 업데이트
                self.drawView.setNeedsDisplay()
            }
        }
    }
}
