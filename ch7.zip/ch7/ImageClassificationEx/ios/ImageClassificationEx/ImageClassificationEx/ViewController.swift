import UIKit
import FirebaseMLVision //(3)

//라벨링(이미지)
class ViewController: UIViewController,
    UINavigationControllerDelegate,
    UIImagePickerControllerDelegate {
    //UI
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var lblText: UILabel!
    @IBOutlet weak var segmentControl: UISegmentedControl!


//====================
//라이프사이클
//====================
    //뷰 표시시 호출
    override func viewDidAppear(_ animated: Bool) {
        //액션시트 표시
        if self.imageView.image == nil {
            showActionSheet()
        }
    }
    
    
//====================
//이벤트
//====================
    //화면 터치시 호출
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        showActionSheet()
    }
   

//====================
//액션시트
//====================
    //액션시트 표시
    func showActionSheet() {
        let actionSheet = UIAlertController(title: nil, message: nil,
            preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "카메라", style: .default) {
            action in
            self.openPicker(sourceType: .camera)
        })
        actionSheet.addAction(UIAlertAction(title: "사진 라이브러리", style: .default) {
            action in
            self.openPicker(sourceType: .photoLibrary)
        })
        actionSheet.addAction(UIAlertAction(title: "취소", style: .cancel))
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    
//====================
//경고
//====================
    //경고표시
    func showAlert(_ text: String!) {
        let alert = UIAlertController(title: text, message: nil,
            preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",
            style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
   
   
//====================
//이미지 피커
//====================
    //이미지 피커 열기
    func openPicker(sourceType: UIImagePickerController.SourceType) {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }

    //이미지 피커로 이미지 획득시 호출
    func imagePickerController(_ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //이미지 획득
        var image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        
        //화면방향 보정
        let size = image.size
        UIGraphicsBeginImageContext(size)
        image.draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        image = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()

        //이미지 지정
        self.imageView.image = image
        
        //닫기
        picker.presentingViewController!.dismiss(animated:true, completion:nil)

        //예측
        if self.segmentControl.selectedSegmentIndex == 0 {
            detectLabels(image)
        } else {
            detectCloudLabels(image)
        }
    }
    
    //이미지 피커 취소시 호출
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        //닫기
        picker.presentingViewController!.dismiss(animated:true, completion:nil)
    }
    
    
//====================
//화상분류(이미지)
//====================
    //온디바이스API 화상분류(이미지)
    func detectLabels(_ image: UIImage!) {
        DispatchQueue.global(qos: .default).async {
            //(4)VisionImage 생성
            let visionImage = VisionImage(image: image)
            let imageMetadata = VisionImageMetadata()
            imageMetadata.orientation = self.image2orientation(image)
            visionImage.metadata = imageMetadata
            
            //(5)옵션생성
            let options = VisionLabelDetectorOptions(
                confidenceThreshold: 0.75)
            
            //(6)화상분류 검출기 생성
            let labelDetector = Vision.vision().labelDetector(options: options)

            //(7)화상분류 실행
            labelDetector.detect(in: visionImage) {
                features, error in
                //에러처리
                if error != nil {
                    self.showAlert(error!.localizedDescription)
                    return
                }

                //검출결과 획득
                var text = "\n"
                for feature in features! {
                    text += String(format:"%@ : %d%%\n",
                        feature.label, Int(100*feature.confidence))
                }

                //UI 업데이트
                DispatchQueue.main.async {
                    self.lblText.text = text
                }
            }
        }
    }

    //클라우드API 화상분류(이미지)
    func detectCloudLabels(_ image: UIImage) {
        DispatchQueue.global(qos: .default).async {
            //VisionImage생성
            let visionImage = VisionImage(image: image)
            let imageMetadata = VisionImageMetadata()
            imageMetadata.orientation = self.image2orientation(image)
            visionImage.metadata = imageMetadata

            //(8)화상분류 옵션 생성
            let options = VisionCloudDetectorOptions()
            options.modelType = .latest
            options.maxResults = 20

            //(9)화상분류 검출기 생성
            let labelDetector = Vision.vision().cloudLabelDetector(options: options)

            //(10)화상분류 실행
            labelDetector.detect(in: visionImage) {
                labels, error in
                //에러처리
                if error != nil {
                    self.showAlert(error!.localizedDescription)
                    return
                }

                //검출결과 획득
                var text = "\n"
                for label in labels! {
                    text += String(format:"%@ : %d%%\n",
                        label.label!,
                        Int(100*label.confidence!.floatValue))
                }

                //UI 업데이트
                DispatchQueue.main.async {
                    self.lblText.text = text
                }
            }
        }
    }

    //(4)UIImage→VisionDetectorImageOrientation
    func image2orientation(_ image: UIImage) -> VisionDetectorImageOrientation {
        switch image.imageOrientation {
        case .up:
            return .topLeft
        case .down:
            return .bottomRight
        case .left:
            return .leftBottom
        case .right:
            return .rightTop
        case .upMirrored:
            return .topRight
        case .downMirrored:
            return .bottomLeft
        case .leftMirrored:
            return .leftTop
        case .rightMirrored:
            return .rightBottom
        }
    }
}
